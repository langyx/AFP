/*:
 ## Exercise - Variables
 
 Déclarez une variable appelée `followers` pour représenter le nombre de personnes qui vous suivent sur Instagram. Donnez-lui une valeur comprise entre 0 et 10000. Imprimez la valeur de votre variable en utilisant son nom.
 */

/*:
Supposons maintenant que le lendemain, plus de personnes suivent votre compte. Mettez à jour votre variable `followers` avec un nombre supérieur à celui qu'il est actuellement.
 */

/*:
 Le code ci-dessus est-il compilé(ça veut dire , est ce qu'il fonctionne)?Imprimez votre explication sur la console en utilisant la fonction `print`.
 */


//: page 0 of 10  |  [Next: Exercise - Variables](@next)
