//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)
