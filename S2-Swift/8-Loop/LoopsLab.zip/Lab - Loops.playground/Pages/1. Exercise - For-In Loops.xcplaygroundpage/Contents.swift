/*:
 ## Exercise - For-In Loops
 
Créez une boucle `for-in` qui parcourt les valeurs de 1 à 100 et affiche chacune de ces valeurs.
 */


/*:
Créez un dictionnaire [String : String] où les clés sont les noms des pays et les valeurs sont leurs capitales. Inclure au moins trois paires de clés/valeurs dans votre collection, puis utiliser une boucle `for pour détailler les paires et imprimer les clés et les valeurs dans une phrase.
 ex: La capitale de la France est Paris
 */


//: page 1 of 4  |  [Next: App Exercise - Movements](@next)
