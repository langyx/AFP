/*:
 ## Exercise - For-In Loops
 
 Create a for-in loop that loops through values 1 to 100, and prints each of the values.
 */
for index in 1...100 {
    print(index)
}

}
//: page 1 of 6  |  [Next: App Exercise - Movements](@next)
