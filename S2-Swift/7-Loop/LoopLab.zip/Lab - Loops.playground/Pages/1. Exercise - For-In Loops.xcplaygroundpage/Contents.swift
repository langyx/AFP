/*:
 ## Exercise - For-In Loops
 
Créez une boucle `for-in` qui parcourt les valeurs de 1 à 100 et affiche chacune de ces valeurs.
 */



//: page 1 of 4  |  [Next: App Exercise - Movements](@next)
